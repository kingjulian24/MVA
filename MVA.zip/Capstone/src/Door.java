/* Assignment 2 Question 2
   Filename - Door.java
   Programmer - Mansi Grover 
   This class defines the doors*/
public class Door {
	boolean open;
	boolean hasGrandPrize;
	boolean chosenByContestant;

	Door() {}
}
