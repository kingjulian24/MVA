/* Assignment 2 Question 2
   Filename - PlayManyGames.java,Game.java,Door.java
   Programmer - Mansi Grover
 This program simulates the �Monte Hall paradox�. It asks the user if she wants to �always switch� or �never switch�, and then 
 silently simulate the game 10,000 times given this decision. it then prints out only the overall fraction of times the player 
 win the fabulous grand prize 
   */
import java.io.*;
import java.util.*;

public class PlayManyGames {
	public static void main(String[] args) {
		boolean option;
		int win;
		System.out.print("Want to change door? (y/n)");
		Scanner scan = new Scanner(System.in);
		String a = scan.next();
		if (a.equalsIgnoreCase("y"))
			option = true;
		else
			option = false;
		for (int j = 0; j < 1000; j++) {
			Game theGame = new Game();
			theGame.setUpGame();
			theGame.contestantChooseDoor();
			theGame.monteOpenDoor();
			theGame.winCount(option);
		}
		win = Game.i;
		System.out.println("Number of wins : " + win);
		System.out.println("Probability of winning" + win * 0.1);
	}

}