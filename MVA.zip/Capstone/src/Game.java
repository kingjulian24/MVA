/* Assignment 2 Question 2
   Filename - Game.java
   Programmer - Mansi Grover 
   This class sets up the game and calculates the wins*/
import java.util.*;
public class Game {
	public int grandPrizeDoor, contestantDoor;
	Door door1, door2, door3;
	static int i;

	void setUpGame() {                     //Randomly chooses the grandprize door
		door1 = new Door();
		door2 = new Door();
		door3 = new Door();
		Random r = new Random();
		grandPrizeDoor = r.nextInt(3);
		switch (grandPrizeDoor) {
		case 0:
			door1.hasGrandPrize = true;
			break;
		case 1:
			door2.hasGrandPrize = true;
			break;
		case 2:
			door3.hasGrandPrize = true;
			break;
		}
		
	}

	void contestantChooseDoor() {        //Randomly selects the door chosen by contestant
		Random r = new Random();
		contestantDoor = r.nextInt(3);
		switch (contestantDoor) {
		case 0:
			door1.chosenByContestant = true;
			break;
		case 1:
			door2.chosenByContestant = true;
			break;
		case 2:
			door3.chosenByContestant = true;
			break;
		}
	}

	void monteOpenDoor() {                                                    //Selects the door that surely does not have prize and not selected
		if (door1.chosenByContestant == false && door1.hasGrandPrize == false)//Checks for this door so it can be opened
			door1.open = true;
		else if (door2.chosenByContestant == false
				&& door2.hasGrandPrize == false)
			door2.open = true;
		else
			door3.open = true;
	}
	
	 void printStateOfDoors() {
	        System.out.println("Door 1 is " +
	            (door1.open ? "    open, " : "not open, ") +
	            (door1.hasGrandPrize ? "is     the grand prize, and " : "is not the grand prize, and ") +
	            (door1.chosenByContestant ? "is     chosen." : "is not chosen.") );
	        System.out.println("Door 2 is " +
	            (door2.open ? "    open, " : "not aopen, ") +
	            (door2.hasGrandPrize ? "is     the grand prize, and " : "is not the grand prize, and ") +
	            (door2.chosenByContestant ? "is     chosen." : "is not chosen.") );
	        System.out.println("Door 3 is " +
	            (door3.open ? "    open, " : "not open, ") +
	            (door3.hasGrandPrize ? "is     the grand prize, and " : "is not the grand prize, and ") +
	            (door3.chosenByContestant ? "is     chosen." : "is not chosen.") );
	    }


	void winCount(boolean a) {       //This function calculates the number of wins                                    
		
		
		if (a) {
			if (contestantDoor != grandPrizeDoor) //checks if the 2 doors were initially same as after switching, 
			{	                                  //the chosen door becomes the prize door
			i++;
			switch(contestantDoor)                          //It deselect the door previously selected by the contestant
			{ 
			case 0: door1.chosenByContestant=false;break;
			case 1: door2.chosenByContestant=false;break;
			case 2: door2.chosenByContestant=false;
			}
			switch(grandPrizeDoor)                          //It deselect the door previously selected by the contestant
			{ 
			case 0: door1.chosenByContestant=true;break;
			case 1: door2.chosenByContestant=true;break;
			case 2: door2.chosenByContestant=true;
			}
		} }else {
			if (contestantDoor == grandPrizeDoor)
				i++;
		}
	
}}