/* Assignment 2 Question 1
   Filename - Factorial.java
   Programmer - Mansi Grover
This program calculates the factorial of 2 through 50 using BigIntegers class   
    **Taken help from class notes and Stackoverflow** */
import java.math.*;

public class Factorial {

	public static void main(String[] args) {

		BigInteger a;
		for (int i = 2; i < 51; i++) {
			a = BigInteger.valueOf(i); // Logic from Stackoveflow
			for (int j = (i - 1); j > 0; j--) {
				a = a.multiply(BigInteger.valueOf(j));//calculates the factorial
			}
			System.out.println(i + "! = " + a);
		}

	}

}
